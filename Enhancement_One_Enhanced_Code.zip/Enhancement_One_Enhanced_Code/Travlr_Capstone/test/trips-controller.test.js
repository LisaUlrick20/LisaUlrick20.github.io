
/**
 * CS 499 - Enhancement One
 * Automated Tests: Enhanced Trip Controllers
 *
 * Original Code:
 * The original controllers did not include automated
 * tests for validation or database failures.
 *
 * Enhanced Code:
 * These tests use Jest to simulate MongoDB operations
 * and verify the controller responses.
 *
 * Why This Was Changed:
 * Automated testing helps confirm that the controllers
 * handle successful requests, invalid information,
 * missing trips, and database errors consistently.
 *
 * The MongoDB model is mocked, so these tests do not
 * change actual database records.
 */

jest.mock('../app_api/models/travlr', () => {
    const MockModel = jest.fn();

    MockModel.find = jest.fn();
    MockModel.findOneAndUpdate = jest.fn();

    return MockModel;
});

const Model = require('../app_api/models/travlr');

const {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip
} = require('../app_api/controllers/trips');

// Reusable valid trip information for the tests.
const validTrip = {
    code: 'CAPSTONE-TEST-31',
    name: 'Capstone Backend Updated Trip',
    length: '5 nights / 6 days',
    start: '2027-01-15',
    resort: 'Ocean View Resort',
    perPerson: '$1299.00',
    image: 'ocean-view.jpg',
    description: 'A test trip used for automated controller testing.'
};

// Simulate the Express response object.
const createResponse = () => {
    const res = {};

    res.status = jest.fn().mockReturnValue(res);
    res.json = jest.fn().mockReturnValue(res);

    return res;
};

describe('CS 499 - Enhanced Trip Controller Tests', () => {

    let req;
    let res;

    beforeEach(() => {
        jest.clearAllMocks();

        req = {
            params: { tripCode: 'CAPSTONE-TEST-31' },
            body: { ...validTrip }
        };

        res = createResponse();
    });

    // TEST 1: Retrieve all trips successfully.
    test('returns all trips successfully', async () => {
        Model.find.mockReturnValue({
            exec: jest.fn().mockResolvedValue([validTrip])
        });

        await tripsList(req, res);

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.json).toHaveBeenCalledWith([validTrip]);
    });

    // TEST 2: Return 404 when a trip does not exist.
    test('returns 404 when a trip is not found', async () => {
        Model.find.mockReturnValue({
            exec: jest.fn().mockResolvedValue([])
        });

        await tripsFindByCode(req, res);

        expect(res.status).toHaveBeenCalledWith(404);
        expect(res.json).toHaveBeenCalledWith(
            expect.objectContaining({
                success: false,
                error: expect.objectContaining({
                    code: 'TRIP_NOT_FOUND'
                })
            })
        );
    });

    // TEST 3: Reject invalid Add Trip information.
    test('rejects invalid Add Trip information', async () => {
        req.body = {};

        await tripsAddTrip(req, res);

        expect(res.status).toHaveBeenCalledWith(400);
        expect(res.json).toHaveBeenCalledWith(
            expect.objectContaining({
                success: false,
                error: expect.objectContaining({
                    code: 'VALIDATION_ERROR'
                })
            })
        );

        expect(Model).not.toHaveBeenCalled();
    });

    // TEST 4: Add a valid trip successfully.
    test('adds a valid trip successfully', async () => {
        Model.mockImplementation(() => ({
            save: jest.fn().mockResolvedValue(validTrip)
        }));

        await tripsAddTrip(req, res);

        expect(res.status).toHaveBeenCalledWith(201);
        expect(res.json).toHaveBeenCalledWith(validTrip);
    });

    // TEST 5: Update a valid trip successfully.
    test('updates a valid trip successfully', async () => {
        Model.findOneAndUpdate.mockReturnValue({
            exec: jest.fn().mockResolvedValue(validTrip)
        });

        await tripsUpdateTrip(req, res);

        expect(res.status).toHaveBeenCalledWith(200);
        expect(res.json).toHaveBeenCalledWith(validTrip);
    });

    // TEST 6: Reject invalid Update Trip information.
    test('rejects invalid Update Trip information', async () => {
        req.body.code = 'INVALID@CODE!';

        await tripsUpdateTrip(req, res);

        expect(res.status).toHaveBeenCalledWith(400);
        expect(Model.findOneAndUpdate).not.toHaveBeenCalled();
    });

    // TEST 7: Handle database errors when retrieving trips.
    test('handles database errors when retrieving trips', async () => {
        Model.find.mockReturnValue({
            exec: jest.fn().mockRejectedValue(
                new Error('Simulated database failure')
            )
        });

        const consoleSpy = jest.spyOn(console, 'error')
            .mockImplementation(() => {});

        try {
            await tripsList(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith(
                expect.objectContaining({
                    success: false,
                    error: expect.objectContaining({
                        code: 'DATABASE_ERROR'
                    })
                })
            );
        } finally {
            consoleSpy.mockRestore();
        }
    });

    // TEST 8: Handle database errors when updating a trip.
    test('handles database errors when updating a trip', async () => {
        Model.findOneAndUpdate.mockReturnValue({
            exec: jest.fn().mockRejectedValue(
                new Error('Simulated database failure')
            )
        });

        const consoleSpy = jest.spyOn(console, 'error')
            .mockImplementation(() => {});

        try {
            await tripsUpdateTrip(req, res);

            expect(res.status).toHaveBeenCalledWith(500);
            expect(res.json).toHaveBeenCalledWith(
                expect.objectContaining({
                    success: false,
                    error: expect.objectContaining({
                        code: 'DATABASE_ERROR'
                    })
                })
            );
        } finally {
            consoleSpy.mockRestore();
        }
    });

});
