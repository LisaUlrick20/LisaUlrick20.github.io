
    // Enhancement Two: Create a Destination class to store
    // the information for each travel destination.
    // Keeping the name, image, and description together
    // makes the destinations easier to organize, search, and sort.
    public class Destination {

        // Declare variables to store each destination's
        // name, image file path, and description.
        private String name;
        private String imagePath;
        private String description;

        // Enhancement Two: Create a constructor that accepts
        // the destination's information and stores it in one object.
        public Destination(String name, String imagePath, String description) {
            this.name = name;
            this.imagePath = imagePath;
            this.description = description;
        }

        // Return the name of the destination.
        public String getName() {
            return name;
        }

        // Return the image file path for the destination.
        public String getImagePath() {
            return imagePath;
        }

        // Return the description of the destination.
        public String getDescription() {
            return description;
        }
    }
