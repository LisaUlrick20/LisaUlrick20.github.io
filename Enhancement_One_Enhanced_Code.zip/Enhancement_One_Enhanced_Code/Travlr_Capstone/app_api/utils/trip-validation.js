
/**
 * CS 499 - Enhancement One: Reusable Backend Trip Validation
 *
 * Original Code:
 * The original backend controller accepted trip information
 * directly from API requests and relied mainly on the
 * MongoDB schema to check required fields.
 *
 * Enhanced Code:
 * This reusable module checks required fields, trip codes,
 * trip lengths, prices, and dates before information is
 * submitted to MongoDB.
 *
 * Why This Was Changed:
 * Angular form validation can be bypassed by sending
 * requests directly to the API through tools like Postman.
 *
 * Centralizing backend validation provides consistent
 * rules for both Add Trip and Edit Trip. It also keeps
 * validation separate from the database controller,
 * making the code easier to maintain and test.
 */

// These eight fields are required by the MongoDB trip schema.
const requiredFields = [
    'code',
    'name',
    'length',
    'start',
    'resort',
    'perPerson',
    'image',
    'description'
];

/**
 * Enhancement: Validate a trip's start date.
 *
 * The Angular form normally submits dates as YYYY-MM-DD.
 * This function checks the exact date instead of relying
 * only on JavaScript's automatic date conversion.
 *
 * For example:
 * 2026-12-15 = valid
 * 2026-02-30 = invalid
 * 2026-13-01 = invalid
 */
const isValidDate = (value) => {

    // Require a string in YYYY-MM-DD format.
    if (
        typeof value !== 'string' ||
        !/^\d{4}-\d{2}-\d{2}$/.test(value)
    ) {
        return false;
    }

    // Separate the year, month, and day.
    const [year, month, day] = value.split('-').map(Number);

    // Create a UTC date to avoid local timezone differences.
    const date = new Date(Date.UTC(year, month - 1, day));

    // Compare the resulting date with the original values.
    // Invalid dates may automatically roll into another month.
    return (
        date.getUTCFullYear() === year &&
        date.getUTCMonth() === month - 1 &&
        date.getUTCDate() === day
    );
};

/**
 * Enhancement: Reusable validation for trip information.
 *
 * Returns an array of error messages.
 * An empty array means all validation checks passed.
 *
 * Both Add Trip and Edit Trip will use this function.
 */
const validateTrip = (trip) => {
    const errors = [];

    // Make sure the API received a valid object.
    if (
        !trip ||
        typeof trip !== 'object' ||
        Array.isArray(trip)
    ) {
        return ['Valid trip information is required.'];
    }

    // Check that all eight required fields are present.
    requiredFields.forEach((field) => {
        if (
            typeof trip[field] !== 'string' ||
            trip[field].trim() === ''
        ) {
            errors.push(`${field} is required.`);
        }
    });

    // Check whether a field contains a nonempty string.
    // This prevents duplicate format errors for missing fields.
    const hasValue = (field) =>
        typeof trip[field] === 'string' &&
        trip[field].trim() !== '';

    // Trip codes may contain letters, numbers, and hyphens.
    if (
        hasValue('code') &&
        !/^[A-Za-z0-9-]+$/.test(trip.code)
    ) {
        errors.push(
            'Trip Code can only contain letters, numbers, and hyphens.'
        );
    }

    // Trip length must match the format used in the application.
    if (
        hasValue('length') &&
        !/^\d+\s+nights?\s*\/\s*\d+\s+days?$/i.test(trip.length)
    ) {
        errors.push(
            'Enter the trip length in this format: 4 nights / 5 days.'
        );
    }

    // Validate the actual calendar date.
    if (
        hasValue('start') &&
        !isValidDate(trip.start)
    ) {
        errors.push(
            'Start date must be a valid date in YYYY-MM-DD format.'
        );
    }

    // Price must match the format used in the Angular forms.
    if (
        hasValue('perPerson') &&
        !/^\$\d+\.\d{2}$/.test(trip.perPerson)
    ) {
        errors.push(
            'Enter the price in this format: $799.00.'
        );
    }

    return errors;
};

// Export the functions for use in controllers and tests.
module.exports = {
    validateTrip,
    isValidDate
};
