
/**
 * CS 499 - Enhancement One
 * Automated Tests: Reusable Backend Trip Validation
 *
 * These tests verify that the shared validation function
 * accepts valid trip information and rejects invalid data.
 *
 * This demonstrates how the same validation rules can be
 * tested independently of Express and MongoDB.
 */

const { validateTrip } = require('../app_api/utils/trip-validation');

// Create valid test information to reuse across tests.
const validTrip = {
    code: 'CAPSTONE-TEST-31',
    name: 'Capstone Backend Test Trip',
    length: '5 nights / 6 days',
    start: '2027-01-15',
    resort: 'Ocean View Resort',
    perPerson: '$1299.00',
    image: 'ocean-view.jpg',
    description: 'A trip used for automated validation testing.'
};

describe('CS 499 - Reusable Backend Trip Validation', () => {

    // TEST 1:
    // Valid trip information should pass validation.
    test('accepts valid trip information', () => {
        const errors = validateTrip(validTrip);

        expect(errors).toEqual([]);
    });

    // TEST 2:
    // Missing required fields should be rejected.
    test('rejects missing required fields', () => {
        const errors = validateTrip({});

        expect(errors).toHaveLength(8);
    });

    // TEST 3:
    // Trip codes cannot contain special characters.
    test('rejects invalid trip code characters', () => {
        const trip = {
            ...validTrip,
            code: 'CAPSTONE@TEST!'
        };

        const errors = validateTrip(trip);

        expect(errors.some(error =>
            error.includes('Trip Code')
        )).toBe(true);
    });

    // TEST 4:
    // Incorrect trip length formats should be rejected.
    test('rejects invalid trip length format', () => {
        const trip = {
            ...validTrip,
            length: 'five days'
        };

        const errors = validateTrip(trip);

        expect(errors.length).toBeGreaterThan(0);
    });

    // TEST 5:
    // Incorrect price formats should be rejected.
    test('rejects invalid price format', () => {
        const trip = {
            ...validTrip,
            perPerson: '1299'
        };

        const errors = validateTrip(trip);

        expect(errors.length).toBeGreaterThan(0);
    });

    // TEST 6:
    // Invalid calendar dates should be rejected.
    test('rejects invalid calendar dates', () => {
        const trip = {
            ...validTrip,
            start: '2027-02-30'
        };

        const errors = validateTrip(trip);

        expect(errors.length).toBeGreaterThan(0);
    });

    // TEST 7:
    // Whitespace-only names should be rejected.
    test('rejects whitespace-only trip names', () => {
        const trip = {
            ...validTrip,
            name: '   '
        };

        const errors = validateTrip(trip);

        expect(errors.length).toBeGreaterThan(0);
    });
});
