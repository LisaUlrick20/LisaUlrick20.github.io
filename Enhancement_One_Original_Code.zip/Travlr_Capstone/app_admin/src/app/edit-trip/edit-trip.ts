import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { Router } from '@angular/router';
import { TripData } from '../services/trip-data';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  imports: [CommonModule, ReactiveFormsModule],
  styleUrl: './edit-trip.css',
  templateUrl: './edit-trip.html',
})
export class EditTrip implements OnInit {

  public editForm!: FormGroup;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripService: TripData
  ) {}

  ngOnInit(): void {
    this.editForm = this.formBuilder.group({
      _id: [],
      code: ['', Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required],
    });

    const tripCode = localStorage.getItem('tripCode');

    if (tripCode) {
      this.tripService.getTrip(tripCode)
        .subscribe({
          next: (data: any) => {
            const trip: Trip = Array.isArray(data) ? data[0] : data;

            if (trip) {
              this.editForm.patchValue({
                _id: trip._id,
                code: trip.code,
                name: trip.name,
                length: trip.length,
                start: trip.start
                  ? new Date(trip.start).toISOString().substring(0, 10)
                  : '',
                resort: trip.resort,
                perPerson: trip.perPerson,
                image: trip.image,
                description: trip.description
              });
            }
          },
          error: (error: any) => {
            console.log('Error: ' + error);
          }
        });
    }
  }

  public onSubmit(): void {
    this.submitted = true;

    if (this.editForm.valid) {
      this.tripService.updateTrip(this.editForm.value)
        .subscribe({
          next: (data: any) => {
            console.log(data);
            this.router.navigate(['']);
          },
          error: (error: any) => {
            console.log('Error: ' + error);
          }
        });
    }
  }

  get f() {
    return this.editForm.controls;
  }
}