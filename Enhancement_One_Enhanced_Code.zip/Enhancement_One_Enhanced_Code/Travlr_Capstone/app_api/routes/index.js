
const express = require('express');
const jwt = require('jsonwebtoken'); // Enable JSON Web Tokens

/**
 * CS 499 - Enhancement One: Consistent Authentication Errors
 *
 * Enhanced Code:
 * Import the reusable error-response helper so that
 * authentication failures follow the same JSON
 * structure as the other backend API errors.
 *
 * Why This Was Changed:
 * The original authentication middleware returned
 * different error formats depending on the problem.
 * Using one shared helper makes errors easier to
 * understand, maintain, and test.
 */
const { sendError } = require('../utils/api-response');

const router = express.Router();


const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');


/**
 * CS 499 - Enhancement One: JWT Authentication Error Handling
 *
 * Original Code:
 * The authentication middleware checked for a JWT
 * before allowing users to add or update trips.
 * However, authentication failures returned different
 * response formats, including plain text.
 *
 * Enhanced Code:
 * The middleware now uses the shared sendError helper
 * to return consistent JSON error responses.
 *
 * Why This Was Changed:
 * Consistent responses make authentication problems
 * easier to identify and test without changing which
 * API endpoints require authentication.
 */

// Method to authenticate our JWT
function authenticateJWT(req, res, next) {
    const authHeader = req.headers['authorization'];

    // ENHANCEMENT:
    // Return a structured error when no token is provided.
    if (!authHeader) {
        return sendError(
            res,
            401,
            'AUTH_TOKEN_MISSING',
            'An authentication token is required.'
        );
    }

    // ENHANCEMENT:
    // Check that the header uses the Bearer token format.
    const parts = authHeader.split(' ');

    if (
        parts.length !== 2 ||
        parts[0] !== 'Bearer' ||
        !parts[1]
    ) {
        return sendError(
            res,
            401,
            'AUTH_TOKEN_INVALID',
            'The authorization header must contain a valid Bearer token.'
        );
    }

    const token = parts[1];

    // ORIGINAL FUNCTIONALITY PRESERVED:
    // Verify the JWT using the existing secret.
    jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
        if (err) {
            // ENHANCEMENT:
            // Return consistent errors for invalid or expired tokens.
            return sendError(
                res,
                401,
                'AUTH_TOKEN_INVALID',
                'The authentication token is invalid or has expired.'
            );
        }

        // Preserve the verified user information.
        req.auth = verified;

        // Allow the authenticated request to continue.
        next();
    });
}

router.route('/register').post(authController.register);
router.route('/login').post(authController.login);


router
    .route('/trips')
    .get(tripsController.tripsList)
    .post(authenticateJWT, tripsController.tripsAddTrip);

router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(authenticateJWT, tripsController.tripsUpdateTrip);

module.exports = router;