const Model = require('../models/travlr');

// CS 499 Enhancement One: Reusable backend validation.
const { validateTrip } = require('../utils/trip-validation');

// CS 499 Enhancement One: Consistent API error responses.
const { sendError } = require('../utils/api-response');


/**
 * CS 499 - Enhancement One: Retrieve All Trips
 *
 * Original Code:
 * The controller retrieved trips from MongoDB but did
 * not explicitly handle database errors.
 *
 * Enhanced Code:
 * Added try/catch and the shared API error-response
 * helper to handle database failures consistently.
 *
 * Why This Was Changed:
 * If a database operation fails, the API should return
 * a clear error response instead of leaving the
 * failure without consistent handling.
 */

// GET: /api/trips
// Lists all trips
const tripsList = async (req, res) => {
    try {
        // Retrieve all trips from MongoDB.
        const q = await Model.find({}).exec();

        // An empty array is valid when no trips exist.
        return res.status(200).json(q);

    } catch (error) {
        // Log the database error for troubleshooting.
        console.error('Error retrieving trips:', error);

        // Return a consistent error response.
        return sendError(
            res,
            500,
            'DATABASE_ERROR',
            'Unable to retrieve trips at this time.'
        );
    }
};



/**
 * CS 499 - Enhancement One: Retrieve a Trip by Code
 *
 * Original Code:
 * The controller searched MongoDB for a trip using
 * its trip code. If the trip was not found, it
 * returned a 404 response with an empty object.
 * Database errors were not handled separately.
 *
 * Enhanced Code:
 * Added try/catch to handle database failures.
 * The function now uses the shared API response
 * helper to provide consistent error messages.
 *
 * Why This Was Changed:
 * Returning clear error messages makes it easier
 * to understand why a request failed.
 *
 * Separating missing-trip errors from database
 * failures also makes the API easier to test
 * and maintain.
 */

// GET: /api/trips/:tripCode
// Finds a single trip
const tripsFindByCode = async (req, res) => {
    try {
        // Search MongoDB for the requested trip code.
        const q = await Model
            .find({ code: req.params.tripCode })
            .exec();

        // Return a clear error if no matching trip exists.
        if (!q || q.length === 0) {
            return sendError(
                res,
                404,
                'TRIP_NOT_FOUND',
                'No trip was found with the provided trip code.'
            );
        }

        // Preserve the original array response format
        // so the Angular application continues working.
        return res.status(200).json(q);

    } catch (error) {
        // Log unexpected database errors.
        console.error('Error finding trip:', error);

        // Return a consistent database error response.
        return sendError(
            res,
            500,
            'DATABASE_ERROR',
            'Unable to retrieve the requested trip at this time.'
        );
    }
};



/**
 * CS 499 - Enhancement One: Add Trip Validation
 *
 * Original Code:
 * The Add Trip controller accepted information directly
 * from the API request and created a MongoDB record.
 * It relied mainly on the database schema to check
 * required fields and did not provide detailed errors.
 *
 * Enhanced Code:
 * The controller now uses the reusable validateTrip
 * function before saving information to MongoDB.
 * It also uses the shared sendError helper and
 * try/catch to handle validation and database errors.
 *
 * Why This Was Changed:
 * Angular form validation can be bypassed by sending
 * requests directly to the API through Postman.
 *
 * Backend validation provides another layer of
 * protection and prevents incorrectly formatted
 * information from being saved.
 *
 * Separating validation from database operations
 * also makes the application easier to maintain
 * and test.
 */

// POST: /api/trips
// Adds a new trip
const tripsAddTrip = async (req, res) => {
    try {
        // ENHANCEMENT:
        // Validate the request before creating a trip.
        // This uses the same backend rules for Add and Edit.
        const validationErrors = validateTrip(req.body);

        // Stop the request if any validation errors exist.
        if (validationErrors.length > 0) {
            return sendError(
                res,
                400,
                'VALIDATION_ERROR',
                'Trip information is invalid.',
                validationErrors
            );
        }

        // ORIGINAL FUNCTIONALITY PRESERVED:
        // Create a new trip using the submitted information.
        const newTrip = new Model({
            code: req.body.code,
            name: req.body.name,
            length: req.body.length,
            start: req.body.start,
            resort: req.body.resort,
            perPerson: req.body.perPerson,
            image: req.body.image,
            description: req.body.description
        });

        // Save the validated trip to MongoDB.
        const q = await newTrip.save();

        // Preserve the original successful response.
        return res.status(201).json(q);

    } catch (error) {
        // Log unexpected errors for troubleshooting.
        console.error('Error adding trip:', error);

        // Return a consistent error response.
        return sendError(
            res,
            500,
            'DATABASE_ERROR',
            'Unable to add the trip at this time.'
        );
    }
};



/**
 * CS 499 - Enhancement One: Update Trip Validation
 *
 * Original Code:
 * The Update Trip controller accepted information
 * directly from the API request and updated the
 * matching MongoDB record.
 *
 * The original function did not use reusable backend
 * validation or consistent error responses.
 *
 * Enhanced Code:
 * The controller now calls the shared validateTrip
 * function before updating a trip.
 *
 * It also uses the shared sendError helper and
 * try/catch to handle validation, missing-trip,
 * and database errors.
 *
 * Why This Was Changed:
 * Angular form validation can be bypassed by
 * sending requests directly through Postman.
 *
 * Using the same backend validator for Add Trip
 * and Edit Trip prevents duplicated validation
 * rules and makes the application easier to
 * maintain and test.
 *
 * The existing update operation and successful
 * JSON response format are preserved.
 */

// PUT: /api/trips/:tripCode
// Updates an existing trip
const tripsUpdateTrip = async (req, res) => {
    try {
        // ENHANCEMENT:
        // Validate submitted trip information before
        // attempting to update the MongoDB record.
        const validationErrors = validateTrip(req.body);

        // Reject requests containing invalid information.
        if (validationErrors.length > 0) {
            return sendError(
                res,
                400,
                'VALIDATION_ERROR',
                'Trip information is invalid.',
                validationErrors
            );
        }

        // ORIGINAL FUNCTIONALITY PRESERVED:
        // Find the existing trip by its current code
        // and update it using the validated information.
        const q = await Model
            .findOneAndUpdate(
                { code: req.params.tripCode },
                {
                    code: req.body.code,
                    name: req.body.name,
                    length: req.body.length,
                    start: req.body.start,
                    resort: req.body.resort,
                    perPerson: req.body.perPerson,
                    image: req.body.image,
                    description: req.body.description
                },
                {
                    new: true,
                    runValidators: true
                }
            )
            .exec();

        // ENHANCEMENT:
        // Return a clear error if the trip does not exist.
        if (!q) {
            return sendError(
                res,
                404,
                'TRIP_NOT_FOUND',
                'No trip was found with the provided trip code.'
            );
        }

        // ENHANCEMENT:
        // Return 200 OK for a successful update.
        // Preserve the original JSON document format.
        return res.status(200).json(q);

    } catch (error) {
        // Log unexpected database errors for troubleshooting.
        console.error('Error updating trip:', error);

        // Return a consistent database error response.
        return sendError(
            res,
            500,
            'DATABASE_ERROR',
            'Unable to update the trip at this time.'
        );
    }
};


module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip
};