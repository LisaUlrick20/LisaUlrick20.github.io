
/**
 * CS 499 - Enhancement One
 * Automated API Authentication Tests
 *
 * Original Code:
 * The application protected Add Trip and Edit Trip
 * routes using JSON Web Tokens (JWT).
 *
 * Enhanced Code:
 * Authentication errors now use a consistent JSON
 * response format.
 *
 * Why This Was Changed:
 * Automated tests verify that protected routes reject
 * missing, malformed, and invalid tokens while allowing
 * properly authenticated requests.
 *
 * MongoDB is mocked, so no actual trip records are changed.
 */

const request = require('supertest');
const express = require('express');
const jwt = require('jsonwebtoken');

// Mock the trip controller before loading the API routes.
// This prevents any database operations during these tests.
jest.mock('../app_api/controllers/trips', () => ({
    tripsList: jest.fn((req, res) => res.status(200).json([])),
    tripsFindByCode: jest.fn((req, res) => res.status(200).json([])),
    tripsAddTrip: jest.fn((req, res) =>
        res.status(201).json({ message: 'Trip added' })
    ),
    tripsUpdateTrip: jest.fn((req, res) =>
        res.status(200).json({ message: 'Trip updated' })
    )
}));

// Mock authentication controllers so the actual
// authentication/database modules are not loaded.
jest.mock('../app_api/controllers/authentication', () => ({
    register: jest.fn((req, res) => res.sendStatus(200)),
    login: jest.fn((req, res) => res.sendStatus(200))
}));

const tripsController = require('../app_api/controllers/trips');
const apiRouter = require('../app_api/routes/index');

describe('CS 499 - Automated API Authentication Tests', () => {
    let app;
    const testSecret = 'cs499-automated-test-secret';

    beforeAll(() => {
        process.env.JWT_SECRET = testSecret;

        app = express();
        app.use(express.json());
        app.use('/api', apiRouter);
    });

    beforeEach(() => {
        jest.clearAllMocks();
    });

    // TEST 1: Missing token on Add Trip.
    test('rejects Add Trip requests without a token', async () => {
        const response = await request(app)
            .post('/api/trips')
            .send({});

        expect(response.status).toBe(401);
        expect(response.body.error.code).toBe('AUTH_TOKEN_MISSING');
        expect(tripsController.tripsAddTrip).not.toHaveBeenCalled();
    });

    // TEST 2: Missing token on Edit Trip.
    test('rejects Edit Trip requests without a token', async () => {
        const response = await request(app)
            .put('/api/trips/CAPSTONE-TEST-31')
            .send({});

        expect(response.status).toBe(401);
        expect(response.body.error.code).toBe('AUTH_TOKEN_MISSING');
        expect(tripsController.tripsUpdateTrip).not.toHaveBeenCalled();
    });

    // TEST 3: Incorrect Bearer header format.
    test('rejects incorrectly formatted authorization headers', async () => {
        const response = await request(app)
            .post('/api/trips')
            .set('Authorization', 'INVALID-TOKEN')
            .send({});

        expect(response.status).toBe(401);
        expect(response.body.error.code).toBe('AUTH_TOKEN_INVALID');
        expect(tripsController.tripsAddTrip).not.toHaveBeenCalled();
    });

    // TEST 4: Invalid JWT.
    test('rejects invalid JWT tokens', async () => {
        const response = await request(app)
            .post('/api/trips')
            .set('Authorization', 'Bearer INVALID-TEST-TOKEN')
            .send({});

        expect(response.status).toBe(401);
        expect(response.body.error.code).toBe('AUTH_TOKEN_INVALID');
        expect(tripsController.tripsAddTrip).not.toHaveBeenCalled();
    });

    // TEST 5: Expired JWT.
    test('rejects expired JWT tokens', async () => {
        const expiredToken = jwt.sign(
            { email: 'test@example.com' },
            testSecret,
            { expiresIn: -10 }
        );

        const response = await request(app)
            .put('/api/trips/CAPSTONE-TEST-31')
            .set('Authorization', `Bearer ${expiredToken}`)
            .send({});

        expect(response.status).toBe(401);
        expect(response.body.error.code).toBe('AUTH_TOKEN_INVALID');
        expect(tripsController.tripsUpdateTrip).not.toHaveBeenCalled();
    });

    // TEST 6: Valid JWT allows Add Trip.
    test('allows Add Trip with a valid JWT', async () => {
        const validToken = jwt.sign(
            { email: 'test@example.com' },
            testSecret,
            { expiresIn: '1h' }
        );

        const response = await request(app)
            .post('/api/trips')
            .set('Authorization', `Bearer ${validToken}`)
            .send({});

        expect(response.status).toBe(201);
        expect(tripsController.tripsAddTrip).toHaveBeenCalledTimes(1);
    });

    // TEST 7: Valid JWT allows Edit Trip.
    test('allows Edit Trip with a valid JWT', async () => {
        const validToken = jwt.sign(
            { email: 'test@example.com' },
            testSecret,
            { expiresIn: '1h' }
        );

        const response = await request(app)
            .put('/api/trips/CAPSTONE-TEST-31')
            .set('Authorization', `Bearer ${validToken}`)
            .send({});

        expect(response.status).toBe(200);
        expect(tripsController.tripsUpdateTrip).toHaveBeenCalledTimes(1);
    });

    // TEST 8: Public GET route remains accessible.
    test('allows viewing trips without a JWT', async () => {
        const response = await request(app)
            .get('/api/trips');

        expect(response.status).toBe(200);
        expect(tripsController.tripsList).toHaveBeenCalledTimes(1);
    });
});
