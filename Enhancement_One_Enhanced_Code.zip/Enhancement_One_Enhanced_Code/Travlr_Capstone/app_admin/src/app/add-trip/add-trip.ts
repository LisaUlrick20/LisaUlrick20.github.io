
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule
} from '@angular/forms';
import { Router } from '@angular/router';
import { TripData } from '../services/trip-data';
import { tripValidation } from '../utils/trip-validation';

@Component({
  selector: 'app-add-trip',
  imports: [CommonModule, ReactiveFormsModule],
  styleUrl: './add-trip.css',
  templateUrl: './add-trip.html',
})
export class AddTrip implements OnInit {

  public addForm!: FormGroup;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripService: TripData
  ) {}

  /**
   * CS 499 - Enhancement One: Shared Trip Validation
   *
   * Original Code:
   * The Add Trip form had its own validation rules.
   * These rules only checked whether required fields
   * were filled in. They did not check whether the
   * information was entered in the correct format.
   *
   * Enhanced Code:
   * The form now uses reusable validation rules from
   * trip-validation.ts. These rules check for missing
   * information, incorrect formats, and fields that
   * contain only spaces.
   *
   * Why This Was Changed:
   * Using shared validation rules allows Add Trip and
   * Edit Trip to check information the same way.
   * This reduces duplicate code and makes the
   * application easier to update and maintain.
   */

  ngOnInit(): void {

    // Set up the Add Trip form using the shared validation rules.
    // Both Add Trip and Edit Trip use these rules so the forms
    // follow the same requirements.

    this.addForm = this.formBuilder.group({

      // Keep the trip ID field for consistency with the trip model.
      _id: [''],

      // Apply the shared rules to check each trip field.
      code: ['', tripValidation.code],
      name: ['', tripValidation.name],
      length: ['', tripValidation.length],
      start: ['', tripValidation.start],
      resort: ['', tripValidation.resort],
      perPerson: ['', tripValidation.perPerson],
      image: ['', tripValidation.image],
      description: ['', tripValidation.description]
    });
  }

  /**
   * CS 499 - Enhancement One: Form Submission
   *
   * Original Code:
   * The Add Trip form checked whether required fields
   * were completed before sending the information
   * to the backend API.
   *
   * Enhanced Code:
   * The form now checks the shared validation rules
   * before allowing the information to be submitted.
   * This includes checking required fields and
   * making sure certain values follow the expected
   * formats.
   *
   * Why This Was Changed:
   * Checking the information before submission helps
   * prevent incomplete or incorrectly formatted data
   * from being sent to the backend.
   *
   * The existing API request and navigation behavior
   * have been preserved.
   */

  public onSubmit(): void {

    // Mark the form as submitted so validation messages
    // appear when information is missing or incorrect.
    this.submitted = true;

    // Only continue when every field passes validation.
    if (this.addForm.valid) {

      // Send the new trip information to the backend API.
      this.tripService.addTrip(this.addForm.value)
        .subscribe({

          next: (data: any) => {

            // Return to the trip listing after a successful save.
            console.log(data);
            this.router.navigate(['']);
          },

          // Log an error if the backend cannot save the trip.
          error: (error: any) => {
            console.log('Error: ' + error);
          }
        });
    }
  }

  // Allow the HTML template to check each field's
  // validation status and display the correct messages.
  get f() {
    return this.addForm.controls;
  }
}
