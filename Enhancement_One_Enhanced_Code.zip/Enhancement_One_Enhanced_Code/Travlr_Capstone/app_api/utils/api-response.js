
/**
 * CS 499 - Enhancement One: Consistent API Responses
 *
 * Original Code:
 * The backend controller returned empty objects
 * when requests failed. This made it difficult to
 * understand what caused an error.
 *
 * Enhanced Code:
 * This file provides a reusable function for sending
 * consistent API error responses. Each response
 * includes an error code, message, and optional details.
 *
 * Why This Was Changed:
 * Using the same error structure throughout the API
 * makes problems easier to identify and troubleshoot.
 * It also reduces repeated response-handling code
 * and makes automated testing more consistent.
 */

/**
 * Send a structured error response.
 *
 * status: HTTP status code, such as 400 or 500.
 * code: Short identifier describing the error.
 * message: Explanation of what went wrong.
 * details: Optional additional validation information.
 */
const sendError = (
    res,
    status,
    code,
    message,
    details = []
) => {

    // Return the same error structure for every API failure.
    return res.status(status).json({
        success: false,
        error: {
            code,
            message,
            details
        }
    });
};

// Export the helper so multiple controllers can reuse it.
module.exports = {
    sendError
};
