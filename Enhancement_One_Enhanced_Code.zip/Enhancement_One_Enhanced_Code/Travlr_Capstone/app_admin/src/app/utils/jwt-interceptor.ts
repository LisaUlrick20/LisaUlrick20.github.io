import { inject } from '@angular/core';
import { HttpInterceptorFn } from '@angular/common/http';
import { Authentication } from '../services/authentication';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const authenticationService = inject(Authentication);

  const isAuthAPI =
    req.url.startsWith('login') ||
    req.url.startsWith('register');

  if (authenticationService.isLoggedIn() && !isAuthAPI) {
    const token = authenticationService.getToken();

    const authReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });

    return next(authReq);
  }

  return next(req);
};