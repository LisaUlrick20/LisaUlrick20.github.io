
import { Validators } from '@angular/forms';

/**
 * CS 499 - Enhancement One: Shared Trip Validation
 *
 * Original Code:
 * The Add Trip and Edit Trip components each contained
 * their own validation rules. These rules only checked
 * whether required fields were filled in.
 *
 * Enhanced Code:
 * Created a reusable validation file that both forms
 * can use. The new rules check for missing information,
 * incorrect formats, and fields containing only spaces.
 * The rules also support the existing trip data formats.
 *
 * Why This Was Changed:
 * Keeping the validation rules in one place reduces
 * duplicate code and makes both forms consistent.
 * If a validation rule needs to change later, it can
 * be updated here instead of changing both components.
 *
 * This improves code organization and makes the
 * application easier to maintain and test.
 */

export const tripValidation = {

  // Keep the trip ID field available for the trip model.
  _id: [],

  /**
   * Trip Code Validation
   *
   * Require a trip code and allow letters, numbers,
   * and hyphens. Other special characters are rejected.
   */
  code: [
    Validators.required,
    Validators.pattern(/^[A-Za-z0-9-]+$/)
  ],

  /**
   * Trip Name Validation
   *
   * Require a trip name and reject entries containing
   * only spaces. This prevents blank-looking names.
   */
  name: [
    Validators.required,
    Validators.pattern(/.*\S.*/)
  ],

  /**
   * Trip Length Validation
   *
   * Require the length to follow the existing trip
   * format, such as "4 nights / 5 days".
   *
   * This helps keep trip information consistent.
   */
  length: [
    Validators.required,
    Validators.pattern(/^\d+\s+nights?\s*\/\s*\d+\s+days?$/i)
  ],

  /**
   * Start Date Validation
   *
   * Require a start date before the trip can be saved.
   * The HTML form uses a date input for this field.
   */
  start: [
    Validators.required
  ],

  /**
   * Resort Name Validation
   *
   * Require a resort name and reject entries that
   * contain only spaces.
   */
  resort: [
    Validators.required,
    Validators.pattern(/.*\S.*/)
  ],

  /**
   * Price Per Person Validation
   *
   * Require the price to follow the existing format,
   * such as "$799.00".
   *
   * Prices are stored as strings in the trip data.
   */
  perPerson: [
    Validators.required,
    Validators.pattern(/^\$\d+\.\d{2}$/)
  ],

  /**
   * Image Name Validation
   *
   * Require an image filename to be entered.
   * This does not check whether the image file exists.
   */
  image: [
    Validators.required
  ],

  /**
   * Trip Description Validation
   *
   * Require a description and reject entries that
   * contain only spaces.
   */
  description: [
    Validators.required,
    Validators.pattern(/.*\S.*/)
  ]
};
