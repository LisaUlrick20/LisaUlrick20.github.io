import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JOptionPane;

// Enhancement Two: Import the classes needed to store
// and organize destination objects in a list.
import java.util.ArrayList;
import java.util.List;

// Enhancement Two: Import HashMap to store destinations
// using their names as keys. This will allow us to search
// for destinations without checking each one individually.
import java.util.HashMap;

public class SlideShow extends JFrame {

    // Enhancement Two: Store destination objects in an ArrayList.
    // This makes it easier to organize, search, and sort destinations.
    private List<Destination> destinations;


    // Enhancement Two: Create a HashMap to store destinations
    // using their names as keys for faster searching.
    // This will allow us to compare HashMap lookup with linear search.
    private HashMap<String, Destination> destinationMap;


    // Declare the panels, layouts, and buttons used in the slideshow.
    private JPanel slidePane;
    private JPanel textPane;
    private JPanel buttonPane;
    private CardLayout card;
    private CardLayout cardText;
    private JButton btnPrev;
    private JButton btnNext;

    // Enhancement Two: Add a Search button so users can
    // look for a destination by entering its name.
    private JButton btnSearch;

    // Declare labels for destination images and descriptions.
    private JLabel lblSlide;
    private JLabel lblTextArea;


    // Create the slideshow application and initialize its components.
    public SlideShow() throws HeadlessException {
        initComponent();

        // Enhancement Two: Run the search performance comparison
        // after the destinations and HashMap have been initialized.
        compareSearchPerformance();


        // Enhancement Two: Check the larger test datasets.
        compareLargeDatasetPerformance();


        // Enhancement Two: Verify both sorting methods produce the correct order.
        testSortingCorrectness();


        // Enhancement Two: Compare sorting performance with larger datasets.
        compareSortingPerformance();



    }


    // Enhancement Two: Create additional destinations for testing.
    // Generate test records without changing the five original slides.
    // This will help compare search performance with larger datasets.
    private List<Destination> generateTestDestinations(int count) {

        // Create a separate list to store the test destinations.
        List<Destination> testDestinations = new ArrayList<>();

        // Generate the requested number of destination records.
        for (int i = 1; i <= count; i++) {

            // Give each test destination a unique name.
            testDestinations.add(new Destination(
                "Test Destination " + i,
                "",
                "Destination created for performance testing."
            ));
        }

        // Return the completed list of test destinations.
        return testDestinations;
    }

    // Enhancement Two: Create a HashMap using the test destinations.
    // Store each destination by name so both searching methods
    // can be compared using the same set of records.
    private HashMap<String, Destination> generateTestHashMap(
            List<Destination> testDestinations) {

        // Create an empty HashMap for performance testing.
        HashMap<String, Destination> testMap = new HashMap<>();

        // Add each test destination using its name as the key.
        for (Destination destination : testDestinations) {
            testMap.put(
                destination.getName().toLowerCase(),
                destination
            );
        }

        // Return the completed HashMap.
        return testMap;
    }

    // Enhancement Two: Search a test list one destination at a time.
    // This allows us to measure linear search with larger datasets
    // without changing the five destinations in the slideshow.
    private Destination linearSearchTest(
            List<Destination> testDestinations, String name) {

        // Check each destination until a matching name is found.
        for (Destination destination : testDestinations) {
            if (destination.getName().equalsIgnoreCase(name)) {
                return destination;
            }
        }

        // Return null if the destination does not exist.
        return null;
    }


    // Enhancement Two: Search a larger test dataset using HashMap.
    // Look up the destination by name instead of checking each record.
    // This allows HashMap search to be compared with linear search.
    private Destination hashMapSearchTest(
            HashMap<String, Destination> testMap, String name) {

        // Find the destination using its lowercase name as the key.
        return testMap.get(name.toLowerCase());
    }

    // Enhancement Two: Sort destinations alphabetically using insertion sort.
    // Compare each destination with the ones before it and move
    // larger names forward until the destination is in the correct position.
    private void insertionSort(List<Destination> testDestinations) {

        // Start with the second destination in the list.
        for (int i = 1; i < testDestinations.size(); i++) {

            // Save the destination that needs to be placed in order.
            Destination current = testDestinations.get(i);
            int j = i - 1;

            // Move destinations with larger names one position forward.
            while (j >= 0 &&
                    testDestinations.get(j).getName()
                    .compareToIgnoreCase(current.getName()) > 0) {

                testDestinations.set(j + 1, testDestinations.get(j));
                j--;
            }

            // Place the destination in its correct alphabetical position.
            testDestinations.set(j + 1, current);
        }
    }


    // Enhancement Two: Sort destinations using Java's built-in sorting method.
    // This provides another way to organize destinations alphabetically
    // so its performance can be compared with insertion sort.
    private void builtInSort(List<Destination> testDestinations) {

        // Sort destinations alphabetically without changing the original slides.
        testDestinations.sort((first, second) ->
            first.getName().compareToIgnoreCase(second.getName()));
    }


    // Set up the slideshow interface and its components.
    private void initComponent() {

        // Enhancement Two: Initialize the ArrayList to store
        // all destination information in one organized collection.
        destinations = new ArrayList<>();


        // Enhancement Two: Initialize the HashMap to store
        // destinations by name for faster searching.
        destinationMap = new HashMap<>();


        // Enhancement Two: Add Seoul as the first destination.
        // Store its name, image path, and description together.
        destinations.add(new Destination(
            "Seoul, South Korea",
            "/resources/Sauna Seoul.jpg",
            "After a long day of exploring the streets of Seoul, relax in a jimjilbangs or what is known as a traditional Korean bathhouse and enjoy the soothing hotwater and a peaceful atmosphere."
        ));

        // Enhancement Two: Add Tokyo as the second destination.
        // Store its name, image path, and description together.
        destinations.add(new Destination(
            "Tokyo, Japan",
            "/resources/MtFuji.jpg",
            "Embark on a scenic hike through Tokyo's lush parks and nature trails, where each step brings you closer to the stunning beauty of Mount Fuji."
        ));

        // Enhancement Two: Add Hong Kong as the third destination.
        // Store its name, image path, and description together.
        destinations.add(new Destination(
            "Hong Kong, China",
            "/resources/Hong Kong.jpg",
            "Immerse yourself in tranquility at Chi Lin Nunnery and Nan Lian Garden, where serene nature blends with beautiful traditional Chinese architecture for a peaceful escape."
        ));

        // Enhancement Two: Add Paris as the fourth destination.
        // Store its name, image path, and description together.
        destinations.add(new Destination(
            "Paris, France",
            "/resources/Eiffel Tower.jpg",
            "Unwind and rejuvenate in Paris, where luxurious spas and serene views of the Eiffel Tower offer the perfect blend of detox and relaxation."
        ));

        // Enhancement Two: Add Rome as the fifth destination.
        // Store its name, image path, and description together.
        destinations.add(new Destination(
            "Rome, Italy",
            "/resources/Rome.jpg",
            "Discover the Colosseum, where ancient history meets modern serenity, offering inspiration for travelers seeking reflection and renewal during their wellness retreats in Rome."
        ));

		
        // Enhancement Two: Add each destination from the ArrayList
        // to the HashMap using its name as the key.
        // This allows destinations to be found without searching
        // through the entire list one item at a time.
        for (Destination destination : destinations) {
            destinationMap.put(
                destination.getName().toLowerCase(),
                destination
            );
        }


        // Initialize the layouts and panels used in the slideshow.
        card = new CardLayout();
        cardText = new CardLayout();
        slidePane = new JPanel();
        textPane = new JPanel();

        // Use a white background to make descriptions easier to read.
        textPane.setBackground(Color.WHITE);
        textPane.setBounds(5, 470, 790, 50);
        textPane.setVisible(true);

        // Initialize the navigation buttons and destination labels.
        buttonPane = new JPanel();
        btnPrev = new JButton();
        btnNext = new JButton();

        // Enhancement Two: Initialize the Search button.
        btnSearch = new JButton();

        lblSlide = new JLabel();
        lblTextArea = new JLabel();

        // Set up the application window.
        setSize(800, 600);
        setLocationRelativeTo(null);
        setTitle("Top 5 Destinations SlideShow");
        getContentPane().setLayout(new BorderLayout(10, 50));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Use CardLayout to switch between destination slides.
        slidePane.setLayout(card);
        textPane.setLayout(cardText);

        // Enhancement Two: Create slides using the ArrayList.
        // Each destination object provides its image and description.
        // This replaces the original hardcoded if/else statements.
        for (int i = 0; i < destinations.size(); i++) {
            Destination destination = destinations.get(i);

            lblSlide = new JLabel();
            lblTextArea = new JLabel();

            // Display the image using the stored destination path.
            lblSlide.setText("<html><body><img width='800' height='500' src='"
                + getClass().getResource(destination.getImagePath())
                + "'></body></html>");

            // Display the destination number, name, and description.
            lblTextArea.setText("<html><body><font size='5'>#"
                + (i + 1) + " " + destination.getName()
                + "</font><br>" + destination.getDescription()
                + "</body></html>");

            // Add the image and description to matching slide cards.
            slidePane.add(lblSlide, "card" + (i + 1));
            textPane.add(lblTextArea, "cardText" + (i + 1));
        }

        // Add the destination image and description panels.
        getContentPane().add(slidePane, BorderLayout.CENTER);
        getContentPane().add(textPane, BorderLayout.SOUTH);

        // Arrange the navigation buttons in the button panel.
        buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

        // Move to the previous destination when clicked.
        btnPrev.setText("Previous");
        btnPrev.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goPrevious();
            }
        });
        buttonPane.add(btnPrev);

        // Move to the next destination when clicked.
        btnNext.setText("Next");
        btnNext.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goNext();
            }
        });
        buttonPane.add(btnNext);

        // Enhancement Two: Add the Search button to the slideshow.
        // Users can search for a destination by its name.
        btnSearch.setText("Search");

        // Enhancement Two: Connect the Search button to the
        // method that searches for and displays a destination.
        btnSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchDestination();
            }
        });

        buttonPane.add(btnSearch);

        // Display the navigation buttons at the bottom of the window.
        getContentPane().add(buttonPane, BorderLayout.SOUTH);
    }

    // Move to the previous destination and its matching description.
    private void goPrevious() {
        card.previous(slidePane);
        cardText.previous(textPane);
    }

    // Move to the next destination and its matching description.
    private void goNext() {
        card.next(slidePane);
        cardText.next(textPane);
    }

    // Enhancement Two: Use linear search to find a destination.
    // Check each destination in the ArrayList until a name matches.
    // Return the destination if found, or null if no match exists.
    // Time complexity: O(n), because every item may need checking.
    private Destination linearSearch(String name) {
        for (Destination destination : destinations) {
            if (destination.getName().equalsIgnoreCase(name)) {
                return destination;
            }
        }

        // Return null when no matching destination is found.
        return null;
    }


    // Enhancement Two: Search for a destination using HashMap.
    // Use the destination name as a key to find its information.
    // Unlike linear search, HashMap does not need to check
    // each destination individually.
    // Average time complexity: O(1) for faster lookups.
    private Destination hashMapSearch(String name) {

        // Convert the name to lowercase to match the stored keys.
        return destinationMap.get(name.toLowerCase());
    }


    // Enhancement Two: Measure how long linear search takes.
    // Use System.nanoTime() to record the start and end times.
    // Display the elapsed time in nanoseconds for comparison.
    private long measureLinearSearch(String name) {

        // Record the time before starting the search.
        long startTime = System.nanoTime();

        // Run linear search using the destination name.
        linearSearch(name);

        // Record the time after the search finishes.
        long endTime = System.nanoTime();

        // Return the total time spent searching.
        return endTime - startTime;
    }


    // Enhancement Two: Measure how long HashMap search takes.
    // Use System.nanoTime() to record the start and end times.
    // Display the elapsed time in nanoseconds for comparison.
    private long measureHashMapSearch(String name) {

        // Record the time before starting the search.
        long startTime = System.nanoTime();

        // Run HashMap search using the destination name.
        hashMapSearch(name);

        // Record the time after the search finishes.
        long endTime = System.nanoTime();

        // Return the total time spent searching.
        return endTime - startTime;
    }


    // Enhancement Two: Compare linear search and HashMap search.
    // Run each search multiple times to collect timing results.
    // This helps reduce the effect of timing differences
    // that can happen when measuring a single search.
    private void compareSearchPerformance() {

        // Choose the same destination for both searching methods.
        String searchName = "Rome, Italy";

        // Set how many times each search will run.
        int repetitions = 10000;

        // Store the total time for each searching method.
        long linearTotal = 0;
        long hashMapTotal = 0;

        // Run linear search repeatedly and add the elapsed times.
        for (int i = 0; i < repetitions; i++) {
            linearTotal += measureLinearSearch(searchName);
        }

        // Run HashMap search repeatedly and add the elapsed times.
        for (int i = 0; i < repetitions; i++) {
            hashMapTotal += measureHashMapSearch(searchName);
        }

        // Calculate the average time for each search.
        double linearAverage = (double) linearTotal / repetitions;
        double hashMapAverage = (double) hashMapTotal / repetitions;

        // Display the average search times in the terminal.
        System.out.println("Linear Search Average: "
            + linearAverage + " ns");
        System.out.println("HashMap Search Average: "
            + hashMapAverage + " ns");
    }


    // Enhancement Two: Compare search performance with larger datasets.
    // Test 100, 1,000, and 10,000 destinations using both search methods.
    // Keep the test data separate from the five original slideshow destinations.
    private void compareLargeDatasetPerformance() {

        // Set the dataset sizes and number of searches for each test.
        int[] datasetSizes = {100, 1000, 10000};
        int repetitions = 10000;

        // Test each dataset size separately.
        for (int size : datasetSizes) {

            // Create the test destinations and matching HashMap.
            List<Destination> testDestinations =
                generateTestDestinations(size);

            HashMap<String, Destination> testMap =
                generateTestHashMap(testDestinations);

            // Search for the last destination in each dataset.
            // This makes linear search check the entire list.
            String searchName = "Test Destination " + size;

            // Warm up both methods before measuring their performance.
            for (int i = 0; i < repetitions; i++) {
                linearSearchTest(testDestinations, searchName);
                hashMapSearchTest(testMap, searchName);
            }

            // Measure the total time for repeated linear searches.
            long linearStart = System.nanoTime();

            for (int i = 0; i < repetitions; i++) {
                linearSearchTest(testDestinations, searchName);
            }

            long linearTotal = System.nanoTime() - linearStart;

            // Measure the total time for repeated HashMap searches.
            long hashMapStart = System.nanoTime();

            for (int i = 0; i < repetitions; i++) {
                hashMapSearchTest(testMap, searchName);
            }

            long hashMapTotal = System.nanoTime() - hashMapStart;

            // Calculate the average time for each search.
            double linearAverage = (double) linearTotal / repetitions;
            double hashMapAverage = (double) hashMapTotal / repetitions;

            // Display the results in the terminal.
            System.out.println();
            System.out.println("Dataset Size: " + size);
            System.out.println("ArrayList Records: "
                + testDestinations.size());
            System.out.println("HashMap Records: "
                + testMap.size());

            System.out.printf("Linear Search Average: %.2f ns%n",
                linearAverage);
            System.out.printf("HashMap Search Average: %.2f ns%n",
                hashMapAverage);
        }
    }


    // Enhancement Two: Check that both sorting methods work correctly.
    // Use a small list of destinations in a mixed alphabetical order.
    // Keep this test separate from the original slideshow.
    private void testSortingCorrectness() {

        // Create a small list of destinations to sort.
        List<Destination> testDestinations = new ArrayList<>();

        testDestinations.add(new Destination("Tokyo", "", ""));
        testDestinations.add(new Destination("Rome", "", ""));
        testDestinations.add(new Destination("Paris", "", ""));
        testDestinations.add(new Destination("Seoul", "", ""));

        // Make separate copies so each sorting method
        // starts with the same unsorted destinations.
        List<Destination> insertionList =
            new ArrayList<>(testDestinations);

        List<Destination> builtInList =
            new ArrayList<>(testDestinations);

        // Sort the first list using insertion sort.
        insertionSort(insertionList);

        // Sort the second list using Java's built-in sort.
        builtInSort(builtInList);

        // Display both sorted lists in the terminal.
        System.out.println();
        System.out.println("Insertion Sort Results:");

        for (Destination destination : insertionList) {
            System.out.println(destination.getName());
        }

        System.out.println();
        System.out.println("Built-In Sort Results:");

        for (Destination destination : builtInList) {
            System.out.println(destination.getName());
        }

        // Check that both methods produced the expected order.
        String expected = "Paris, Rome, Seoul, Tokyo";

        String insertionResult = String.join(", ",
            insertionList.stream().map(Destination::getName).toList());

        String builtInResult = String.join(", ",
            builtInList.stream().map(Destination::getName).toList());

        boolean insertionPassed = expected.equals(insertionResult);
        boolean builtInPassed = expected.equals(builtInResult);

        System.out.println();
        System.out.println("Insertion Sort Test: "
            + (insertionPassed ? "PASS" : "FAIL"));
        System.out.println("Built-In Sort Test: "
            + (builtInPassed ? "PASS" : "FAIL"));
    }


    // Enhancement Two: Compare insertion sort with Java's built-in sort.
    // Test both algorithms using larger datasets in reverse order.
    // Keep the test data separate from the original slideshow.
    private void compareSortingPerformance() {

        // Use three dataset sizes for the sorting comparison.
        int[] datasetSizes = {100, 1000, 10000};

        // Test each dataset size separately.
        for (int size : datasetSizes) {

            // Create a list of destinations in reverse order.
            List<Destination> testDestinations = new ArrayList<>();

            for (int i = size; i >= 1; i--) {
                testDestinations.add(new Destination(
                    String.format("Test Destination %05d", i),
                    "",
                    "Destination created for sorting performance testing."
                ));
            }

            // Give both algorithms their own copy of the same data.
            List<Destination> insertionList =
                new ArrayList<>(testDestinations);

            List<Destination> builtInList =
                new ArrayList<>(testDestinations);

            // Measure how long insertion sort takes.
            long insertionStart = System.nanoTime();
            insertionSort(insertionList);
            long insertionTime = System.nanoTime() - insertionStart;

            // Measure how long Java's built-in sort takes.
            long builtInStart = System.nanoTime();
            builtInSort(builtInList);
            long builtInTime = System.nanoTime() - builtInStart;

            // Check that both methods produced the same sorted order.
            boolean resultsMatch = true;

            for (int i = 0; i < size; i++) {
                if (!insertionList.get(i).getName().equals(
                        builtInList.get(i).getName())) {
                    resultsMatch = false;
                    break;
                }
            }

            // Display the performance results in the terminal.
            System.out.println();
            System.out.println("Sorting Dataset Size: " + size);

            System.out.printf("Insertion Sort Time: %.2f ms%n",
                insertionTime / 1_000_000.0);

            System.out.printf("Built-In Sort Time: %.2f ms%n",
                builtInTime / 1_000_000.0);

            System.out.println("Sorting Results Match: "
                + (resultsMatch ? "PASS" : "FAIL"));
        }
    }



    // Enhancement Two: Allow users to search for a destination.
    // Use linear search to locate the destination in the ArrayList.
    // If found, automatically display the matching slide.
    private void searchDestination() {

        // Ask the user to enter the name of a destination.
        String name = JOptionPane.showInputDialog(
            this, "Enter a destination name:"
        );

        // Stop searching if the user cancels or enters a blank name.
        if (name == null || name.trim().isEmpty()) {
            return;
        }

 
        // Enhancement Two: Use HashMap to find the destination
        // by its name instead of checking each item in the ArrayList.
        // This lets us test HashMap searching separately from linear search.
        Destination result = hashMapSearch(name.trim());


        if (result != null) {

            // Enhancement Two: Find the destination's position
            // and use it to display the correct image and description.
            int index = destinations.indexOf(result) + 1;

            card.show(slidePane, "card" + index);
            cardText.show(textPane, "cardText" + index);

            // Confirm that the destination was found.
            JOptionPane.showMessageDialog(
                this, "Destination found: " + result.getName()
            );

        } else {

            // Let the user know when no matching destination exists.
            JOptionPane.showMessageDialog(
                this, "Destination not found."
            );
        }
    }

    // Launch the application and display the slideshow window.
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                SlideShow ss = new SlideShow();
                ss.setVisible(true);
            }
        });
    }
}
