
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule
} from '@angular/forms';
import { Router } from '@angular/router';
import { TripData } from '../services/trip-data';
import { Trip } from '../models/trip';
import { tripValidation } from '../utils/trip-validation';

@Component({
  selector: 'app-edit-trip',
  imports: [CommonModule, ReactiveFormsModule],
  styleUrl: './edit-trip.css',
  templateUrl: './edit-trip.html',
})
export class EditTrip implements OnInit {

  public editForm!: FormGroup;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripService: TripData
  ) {}

  /**
   * CS 499 - Enhancement One: Shared Edit Trip Validation
   *
   * Original Code:
   * The Edit Trip form used its own validation rules.
   * These rules only checked whether required fields
   * were filled in. They did not check whether the
   * information was entered in the correct format.
   *
   * Enhanced Code:
   * The form now uses the reusable validation rules
   * from trip-validation.ts. These rules check for
   * missing information, incorrect formats, and fields
   * that contain only spaces.
   *
   * Why This Was Changed:
   * Using the same validation rules in Add Trip and
   * Edit Trip reduces duplicate code and keeps both
   * forms consistent. It also makes future validation
   * changes easier to maintain.
   */

  ngOnInit(): void {

    // Set up the Edit Trip form using the shared validation rules.
    // Both Add Trip and Edit Trip now follow the same requirements.
    this.editForm = this.formBuilder.group({

      // Keep the trip ID so the correct trip can be updated.
      _id: [],

      // Apply the shared validation rules to each trip field.
      code: ['', tripValidation.code],
      name: ['', tripValidation.name],
      length: ['', tripValidation.length],
      start: ['', tripValidation.start],
      resort: ['', tripValidation.resort],
      perPerson: ['', tripValidation.perPerson],
      image: ['', tripValidation.image],
      description: ['', tripValidation.description]
    });

    /**
     * CS 499 - Enhancement One: Loading Existing Trip Data
     *
     * Original Code:
     * The Edit Trip form retrieved the selected trip
     * and displayed its existing information.
     *
     * Enhanced Code:
     * This original functionality has been preserved
     * while the form now uses shared validation rules.
     * The existing trip information is loaded into
     * fields that follow the same validation requirements
     * as the Add Trip form.
     *
     * Why This Was Changed:
     * Administrators can continue editing existing trips
     * while the updated form checks the information
     * before changes are saved.
     */

    // Get the trip code saved when the administrator selected Edit Trip.
    const tripCode = localStorage.getItem('tripCode');

    if (tripCode) {

      // Request the existing trip information from the backend API.
      this.tripService.getTrip(tripCode)
        .subscribe({
          next: (data: any) => {

            // Handle the response whether it contains one trip or an array.
            const trip: Trip = Array.isArray(data) ? data[0] : data;

            if (trip) {

              // Fill the form with the trip's current information.
              // Format the date so it works with the HTML date field.
              this.editForm.patchValue({
                _id: trip._id,
                code: trip.code,
                name: trip.name,
                length: trip.length,
                start: trip.start
                  ? new Date(trip.start).toISOString().substring(0, 10)
                  : '',
                resort: trip.resort,
                perPerson: trip.perPerson,
                image: trip.image,
                description: trip.description
              });
            }
          },

          // Log an error if the trip cannot be loaded.
          error: (error: any) => {
            console.log('Error: ' + error);
          }
        });
    }
  }

  /**
   * CS 499 - Enhancement One: Edit Trip Submission
   *
   * Original Code:
   * The Edit Trip form checked whether required fields
   * were completed before sending updated information
   * to the backend API.
   *
   * Enhanced Code:
   * The form now checks the shared validation rules
   * before submitting changes. This includes checking
   * required fields and making sure certain values
   * follow the expected formats.
   *
   * Why This Was Changed:
   * Checking the information before submission helps
   * prevent incomplete or incorrectly formatted data
   * from being sent to the backend.
   *
   * The existing update request and navigation behavior
   * have been preserved.
   */

  public onSubmit(): void {

    // Mark the form as submitted so validation messages can appear.
    this.submitted = true;

    // Only continue when all fields pass validation.
    if (this.editForm.valid) {

      // Send the updated trip information to the backend API.
      this.tripService.updateTrip(this.editForm.value)
        .subscribe({
          next: (data: any) => {

            // Return to the trip listing after a successful update.
            console.log(data);
            this.router.navigate(['']);
          },

          // Log an error if the backend cannot update the trip.
          error: (error: any) => {
            console.log('Error: ' + error);
          }
        });
    }
  }

  // Allow the HTML template to access each field's
  // validation status and display the correct messages.
  get f() {
    return this.editForm.controls;
  }
}
